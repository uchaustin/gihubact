package org.deanace.constant;

public interface S3Constant {

    String SOURCE_BUCKET_NAME = "bucket-source-01";
    String SOURCE_OBJECT_KEY = "xxxxxxxxx";
    String DESTINATION_BUCKET_NAME = "bucket-destination-01";
    String DESTINATION_OBJECT_KEY = "xxxxxxxxx";
    String LOCATION = "US East (Ohio) us-east-2";
}
