package org.deanace;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.lambda.runtime.events.models.s3.S3EventNotification;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.deanace.constant.S3Constant.*;

/**
 * Hello world!
 *
 */
public class S3EventHandler implements RequestHandler<S3Event, Boolean> {

    // create S3 client
    /**
    private static final AmazonS3 s3AwsClient = AmazonS3Client.builder()
            .withCredentials(new DefaultAWSCredentialsProviderChain()).build();
    **/
    /* Create S3 Client Object */
    AmazonS3 amazonS3 = AmazonS3ClientBuilder
            .standard()
            .withRegion(Regions.AP_SOUTH_1)
            .withCredentials(new AWSStaticCredentialsProvider(
                    new BasicAWSCredentials("ACCESS_KEY","SECRET_KEY")))
            .build();

    @Override
    public Boolean handleRequest(S3Event s3Event, Context context) {
        final LambdaLogger logger = context.getLogger();
        if(s3Event.getRecords().isEmpty()) {
            logger.log("Record not found.");
            return false;
        }
        // process the records
        try {
            /* Arguments: SourceBucketName, SourceObjectKey, DestinationBucketName, DestinationObjectKey */
            CopyObjectRequest request = new CopyObjectRequest(SOURCE_BUCKET_NAME, SOURCE_OBJECT_KEY,
                    DESTINATION_BUCKET_NAME, DESTINATION_OBJECT_KEY);
            /* Set StorageClass as Standard Infrequent Access */
            request.setStorageClass(StorageClass.StandardInfrequentAccess);
            /* Set Canned ACL as BucketOwnerFullControl */
            request.setCannedAccessControlList(CannedAccessControlList.BucketOwnerFullControl);
            /* Set Destination Metadata */
            Map<String, String> map = new HashMap<>();
            map.put("location", LOCATION);

            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setUserMetadata(map);

            request.setNewObjectMetadata(metadata);

            /* Set Destination Tags */
            List<Tag> tags = new ArrayList<>();
            tags.add(new Tag("column1", "s3"));
            tags.add(new Tag("column2", "png"));
            request.setNewObjectTagging(new ObjectTagging(tags));
            /* Send Copy Object Request */
            CopyObjectResult result = amazonS3.copyObject(request);

        } catch (AmazonS3Exception s3Exception) {
            logger.log(s3Exception.getMessage());
        }
        return null;
    }
}
