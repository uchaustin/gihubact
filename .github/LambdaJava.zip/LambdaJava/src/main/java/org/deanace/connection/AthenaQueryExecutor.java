package org.deanace.connection;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;

import static org.deanace.constant.AthenaConstants.*;

import java.sql.*;
import java.util.Properties;

public class AthenaQueryExecutor {

    public void execute(Context context){
        final LambdaLogger logger = context.getLogger();
        Properties properties = new Properties();
        Connection connection = null;
        Statement statement = null;
        try {
            setProperties(properties);
            // load driver class
            Class.forName(DRIVER_CLASS);
            connection = DriverManager.getConnection(connectionUrl, properties);
            logger.log("connected ");
            statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery(QUERY);
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();

            while (resultSet.next()){
                System.out.println(resultSet.getString(1) + "\t" +
                        resultSet.getString(2) + "\t" +
                        resultSet.getString(3));
            }
        } catch (Exception exception){
            logger.log("failed to connect "+exception.getMessage());
        } finally {
            try{if(connection != null) connection.close();}catch (Exception e){}
            try{if(statement != null) statement.close();}catch (Exception e){}
        }
    }

    private void setProperties(Properties properties) {
        // set system properties
        System.setProperty("aws.accessKeyId", AWS_ACCESS_KEY);
        System.setProperty("aws.secretKey", AWS_SECRET_KEY);
        //set Athena props
        properties.setProperty("S3OutputLocation", s3OutputLocation);
        properties.setProperty("AwsCredentialsProviderClass", "com.simba.athena.amazonaws.auth.SystemPropertiesCredentialsProvider");
    }
}
