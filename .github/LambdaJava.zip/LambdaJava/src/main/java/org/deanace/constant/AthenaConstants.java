package org.deanace.constant;

public interface AthenaConstants {
    String AWS_ACCESS_KEY = "xxxxxx"; // provide your own key. Check the image I sent
    String AWS_SECRET_KEY = "xxxxxx";// provide your own key. Check the image I sent
    String connectionUrl = "jdbc:awsathena://AwsReqion=us-east-1";
    String s3OutputLocation = "s3://ajay-athen-lab/athena-output";// you can get this from your AWS console url : Amazon S3 >> athena-lab >> athena-output
    String QUERY = "SELECT count(station) AS Num_of_stations,\n" +
        "fuel,\n"+
        "state\n"+
        "FROM \"mydatabase\".\"electricity\"\n"+
        "WHERE year= '2016'\n" +
        "AND fuel='COAL'\n +" +
                "GROUP BY fuel, state;";
    String DRIVER_CLASS = "com.simba.athena.jdbc.Driver";
}
